package com.evs.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EvsApplication.class, args);
	}

}