import React from "react";
import "../App.css";

export default function Footer() {
  return (
    <div className="foot">
      <footer>&copy; E-vote india</footer>
    </div>
  );
}
